echo -e -n "\e[32mdo you installed ngrok? (y/n) : "
read yes
if [ $yes = "y" ]
then
cd /$HOME/Easyphish/main-builds/
bash to-start.sh
fi

if [ $yes = "n" ]
then
cd /$HOME/Easyphish/main-builds/
bash to-install.sh
fi
